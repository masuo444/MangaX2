// DOM要素
const titleInput = document.getElementById('titleInput');
const pageContentTextarea = document.getElementById('pageContent');
const charCountSpan = document.getElementById('charCount');
const aspectRatioSelect = document.getElementById('aspectRatio');
const generateButtons = document.querySelectorAll('.generate-btn');
const checkUpdateBtn = document.getElementById('checkUpdateBtn');
const apiSettingsBtn = document.getElementById('apiSettingsBtn');
const apiModal = document.getElementById('apiModal');
const apiKeyInput = document.getElementById('apiKeyInput');
const saveApiBtn = document.getElementById('saveApiBtn');
const cancelApiBtn = document.getElementById('cancelApiBtn');
const closeModal = document.querySelector('.close');
const imageModal = document.getElementById('imageModal');
const modalImage = document.getElementById('modalImage');
const toastElement = document.getElementById('toast');
const novelDropZone = document.getElementById('novelDropZone');
const novelFileInput = document.getElementById('novelFileInput');
const novelMeta = document.getElementById('novelMeta');
const novelFileNameSpan = document.getElementById('novelFileName');
const novelCharCountSpan = document.getElementById('novelCharCount');
const removeNovelBtn = document.getElementById('removeNovelBtn');

let currentPageContent = '';
let falApiKey = null;
let generatedImages = {}; // スタイルごとの生成画像を保存
let designConfig = null; // デザイン設定
let designGroups = []; // デザイングループのリスト
let activeTab = 'home'; // 現在アクティブなタブ
let currentEditingGroupId = null; // 現在編集中のグループID
let tempDesigns = []; // 編集中のデザイン一時保存
const MAX_CHARACTERS = 5;
let characterImages = []; // { id, name, base64 }
let imageLibrary = []; // 画像ライブラリ
let currentLibraryTarget = null; // { type: 'character', id?: string }
let novelContent = ''; // アップロードした小説テキスト
let novelFileName = '';

// トースト表示関数
function showToast(message, duration = 5000) {
  toastElement.textContent = message;
  toastElement.classList.add('show');

  setTimeout(() => {
    toastElement.classList.remove('show');
  }, duration);
}

// 初期化
document.addEventListener('DOMContentLoaded', async () => {
  // デザイン設定を読み込む
  await loadDesignConfig();

  // デザイングループを読み込む
  await loadDesignGroups();

  // キャラクターシートを読み込む
  await loadCharacterSheet();

  // 原作テキストを読み込む
  await loadNovelContent();

  // 画像ライブラリを初期化
  await initImageLibrary();

  // URLパラメータからページ内容を取得（background.jsから渡される）
  const urlParams = new URLSearchParams(window.location.search);
  const contentParam = urlParams.get('content');

  if (contentParam) {
    currentPageContent = decodeURIComponent(contentParam);
    pageContentTextarea.value = currentPageContent;
    updateCharCount();
  } else {
    // ストレージから取得
    const result = await chrome.storage.local.get('pendingPageContent');
    if (result.pendingPageContent) {
      currentPageContent = result.pendingPageContent;
      pageContentTextarea.value = currentPageContent;
      updateCharCount();
      // 使用後は削除
      await chrome.storage.local.remove('pendingPageContent');
    }
  }

  setupEventListeners();
  setupTabListeners();

  // APIキーを読み込む
  await loadApiKey();

  // サンプル画像にクリックイベントを追加
  setupSampleImageClickEvents();

  // 初期ボタン状態を更新
  updateButtonStates();
});

// デザイン設定を読み込む
async function loadDesignConfig() {
  try {
    const response = await fetch('design/default/design.json');
    designConfig = await response.json();

    // 画像パスを絶対パスに変換（design.jsonからの相対パスをルートからのパスに変換）
    if (designConfig && designConfig.designs) {
      designConfig.designs = designConfig.designs.map(design => {
        if (design.sampleImage && !design.sampleImage.startsWith('design/')) {
          // 相対パス（images/xxx.jpg）を絶対パス（design/default/images/xxx.jpg）に変換
          design.sampleImage = 'design/default/' + design.sampleImage;
        }
        return design;
      });
    }

    // スタイルグリッドを生成
    generateStyleGrid();
  } catch (error) {
    console.error('Failed to load design config:', error);
    alert('デザイン設定の読み込みに失敗しました');
  }
}

// デザイングループを読み込む
async function loadDesignGroups() {
  const result = await chrome.storage.local.get('designGroups');
  if (result.designGroups && Array.isArray(result.designGroups)) {
    designGroups = result.designGroups;
    renderDesignGroups();
  }
}

// デザイングループを保存
async function saveDesignGroups() {
  await chrome.storage.local.set({ designGroups: designGroups });
}

// キャラクターシートを読み込む
async function loadCharacterSheet() {
  try {
    const result = await chrome.storage.local.get('characterSheet');
    if (result.characterSheet && Array.isArray(result.characterSheet)) {
      characterImages = result.characterSheet.map(c => ({
        id: c.id || `character-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        name: c.name || '',
        base64: c.base64 || null
      }));
    }
  } catch (error) {
    console.error('Failed to load character sheet:', error);
  }

  if (characterImages.length === 0) {
    characterImages.push(createEmptyCharacterSlot());
  }
}

// キャラクターシートを保存
async function saveCharacterSheet() {
  try {
    await chrome.storage.local.set({ characterSheet: characterImages });
  } catch (error) {
    console.error('Failed to save character sheet:', error);
  }
}

// 原作テキストを読み込む
async function loadNovelContent() {
  try {
    const result = await chrome.storage.local.get(['novelContent', 'novelFileName']);
    novelContent = result.novelContent || '';
    novelFileName = result.novelFileName || '';
    updateNovelMeta();
  } catch (error) {
    console.error('Failed to load novel content:', error);
  }
}

// 原作テキストを保存
async function saveNovelContent() {
  try {
    await chrome.storage.local.set({ novelContent, novelFileName });
  } catch (error) {
    console.error('Failed to save novel content:', error);
  }
}


// デザイングループをレンダリング
function renderDesignGroups() {
  const tabNav = document.querySelector('.tab-nav');
  const tabContent = document.querySelector('.tab-content');

  // 既存のカスタムタブを削除
  const customTabs = tabNav.querySelectorAll('.tab-btn[data-custom="true"]');
  customTabs.forEach(tab => tab.remove());

  const customPanes = tabContent.querySelectorAll('.tab-pane[data-custom="true"]');
  customPanes.forEach(pane => pane.remove());

  // デザイングループごとにタブを追加
  designGroups.forEach((group, index) => {
    // タブボタンを追加
    const tabBtn = document.createElement('button');
    tabBtn.className = 'tab-btn';
    tabBtn.dataset.tab = group.id;
    tabBtn.dataset.custom = 'true';
    tabBtn.textContent = group.name;
    tabNav.appendChild(tabBtn);

    // タブコンテンツを追加
    const tabPane = document.createElement('div');
    tabPane.className = 'tab-pane';
    tabPane.id = `tab-${group.id}`;
    tabPane.dataset.custom = 'true';

    // スタイルグリッドを作成
    const styleGrid = document.createElement('div');
    styleGrid.className = 'style-grid';
    styleGrid.dataset.group = group.id;

    // グループのデザインを表示
    if (group.designs && group.designs.length > 0) {
      group.designs.forEach(design => {
        const styleItem = document.createElement('div');
        styleItem.className = 'style-item';
        const sampleImage = design.sampleImage && design.sampleImage !== null ? design.sampleImage : 'design/no_sample_image.jpg';
        const defaultAspectRatio = design.aspectRatio || '16:9';
        styleItem.innerHTML = `
          <div class="design-area">
            <div class="style-label">${design.name}</div>
            <div class="design-wrapper sample-image">
              <img src="${sampleImage}" alt="${design.name}サンプル">
            </div>
            <div class="aspect-ratio-selector">
              <label>アスペクト比:</label>
              <select class="aspect-ratio-select" data-style="${design.id}" data-group="${group.id}">
                <option value="21:9" ${defaultAspectRatio === '21:9' ? 'selected' : ''}>21:9</option>
                <option value="16:9" ${defaultAspectRatio === '16:9' ? 'selected' : ''}>16:9</option>
                <option value="3:2" ${defaultAspectRatio === '3:2' ? 'selected' : ''}>3:2</option>
                <option value="4:3" ${defaultAspectRatio === '4:3' ? 'selected' : ''}>4:3</option>
                <option value="5:4" ${defaultAspectRatio === '5:4' ? 'selected' : ''}>5:4</option>
                <option value="1:1" ${defaultAspectRatio === '1:1' ? 'selected' : ''}>1:1</option>
                <option value="4:5" ${defaultAspectRatio === '4:5' ? 'selected' : ''}>4:5</option>
                <option value="3:4" ${defaultAspectRatio === '3:4' ? 'selected' : ''}>3:4</option>
                <option value="2:3" ${defaultAspectRatio === '2:3' ? 'selected' : ''}>2:3</option>
                <option value="9:16" ${defaultAspectRatio === '9:16' ? 'selected' : ''}>9:16</option>
              </select>
            </div>
            <button class="generate-btn" data-style="${design.id}" data-group="${group.id}">生成</button>
            <div class="design-display" id="design-${group.id}-${design.id}">
              <div class="design-wrapper generated-image">
                <img src="design/first_image.jpg" alt="生成中">
              </div>
            </div>
            <div class="design-actions">
              <button class="action-btn download-btn" data-style="${design.id}" data-group="${group.id}" disabled>ダウンロード</button>
              <button class="action-btn copy-btn" data-style="${design.id}" data-group="${group.id}" disabled>コピー</button>
            </div>
          </div>
        `;
        styleGrid.appendChild(styleItem);
      });
    }

    tabPane.appendChild(styleGrid);
    tabContent.appendChild(tabPane);
  });

  // タブイベントリスナーを再設定
  setupTabListeners();

  // イベントリスナーを再設定
  setupEventListeners();
  setupSampleImageClickEvents();
}

// スタイルグリッドを動的に生成
function generateStyleGrid() {
  const styleGrid = document.querySelector('.style-grid[data-group="home"]');
  if (!styleGrid || !designConfig) return;

  styleGrid.innerHTML = '';

  const designs = designConfig.designs || designConfig.styles || [];
  designs.forEach(style => {
    const styleItem = document.createElement('div');
    styleItem.className = 'style-item';
    const sampleImageUrl = style.sampleImage && style.sampleImage !== null ? style.sampleImage : 'design/no_sample_image.jpg';
    const defaultAspectRatio = style.aspectRatio || '16:9';
    styleItem.innerHTML = `
      <div class="design-area">
        <div class="style-label">${style.name}</div>
        <div class="design-wrapper sample-image">
          <img src="${sampleImageUrl}" alt="${style.name}サンプル">
        </div>
        <div class="aspect-ratio-selector">
          <label>アスペクト比:</label>
          <select class="aspect-ratio-select" data-style="${style.id}">
            <option value="21:9" ${defaultAspectRatio === '21:9' ? 'selected' : ''}>21:9</option>
            <option value="16:9" ${defaultAspectRatio === '16:9' ? 'selected' : ''}>16:9</option>
            <option value="3:2" ${defaultAspectRatio === '3:2' ? 'selected' : ''}>3:2</option>
            <option value="4:3" ${defaultAspectRatio === '4:3' ? 'selected' : ''}>4:3</option>
            <option value="5:4" ${defaultAspectRatio === '5:4' ? 'selected' : ''}>5:4</option>
            <option value="1:1" ${defaultAspectRatio === '1:1' ? 'selected' : ''}>1:1</option>
            <option value="4:5" ${defaultAspectRatio === '4:5' ? 'selected' : ''}>4:5</option>
            <option value="3:4" ${defaultAspectRatio === '3:4' ? 'selected' : ''}>3:4</option>
            <option value="2:3" ${defaultAspectRatio === '2:3' ? 'selected' : ''}>2:3</option>
            <option value="9:16" ${defaultAspectRatio === '9:16' ? 'selected' : ''}>9:16</option>
          </select>
        </div>
        <button class="generate-btn" data-style="${style.id}">生成</button>
        <div class="design-display" id="design-${style.id}">
          <div class="design-wrapper generated-image">
            <img src="design/first_image.jpg" alt="生成中">
          </div>
        </div>
        <div class="design-actions">
          <button class="action-btn download-btn" data-style="${style.id}" disabled>ダウンロード</button>
          <button class="action-btn copy-btn" data-style="${style.id}" disabled>コピー</button>
        </div>
      </div>
    `;
    styleGrid.appendChild(styleItem);
  });

  // イベントリスナーを再設定
  setupEventListeners();
  setupSampleImageClickEvents();
}

// タブリスナーの設定（初回のみ）
let tabListenersSetup = false;

function setupTabListeners() {
  // タブボタンのクリックイベント（イベント委譲を使用）
  if (!tabListenersSetup) {
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('tab-btn')) {
        switchTab(e.target.dataset.tab);
      }
    });
    tabListenersSetup = true;
  }

  // デザイン編集モーダルの閉じるボタン
  const closeDesignEdit = document.querySelector('.close-design-edit');
  if (closeDesignEdit && !closeDesignEdit.hasAttribute('data-listener-set')) {
    closeDesignEdit.addEventListener('click', closeDesignEditModal);
    closeDesignEdit.setAttribute('data-listener-set', 'true');
  }

  // デザイン編集モーダルのキャンセルボタン
  const cancelDesignEditBtn = document.getElementById('cancelDesignEditBtn');
  if (cancelDesignEditBtn && !cancelDesignEditBtn.hasAttribute('data-listener-set')) {
    cancelDesignEditBtn.addEventListener('click', closeDesignEditModal);
    cancelDesignEditBtn.setAttribute('data-listener-set', 'true');
  }

  // デザイン編集モーダルの保存ボタン
  const saveDesignGroupBtn = document.getElementById('saveDesignGroupBtn');
  if (saveDesignGroupBtn && !saveDesignGroupBtn.hasAttribute('data-listener-set')) {
    saveDesignGroupBtn.addEventListener('click', saveDesignEdits);
    saveDesignGroupBtn.setAttribute('data-listener-set', 'true');
  }

  // デザイン追加ボタン
  const addDesignBtn = document.getElementById('addDesignBtn');
  if (addDesignBtn && !addDesignBtn.hasAttribute('data-listener-set')) {
    addDesignBtn.addEventListener('click', addDesignToEdit);
    addDesignBtn.setAttribute('data-listener-set', 'true');
  }
}

// タブを切り替える
function switchTab(tabId) {
  // すべてのタブボタンとコンテンツからactiveクラスを削除
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabPanes = document.querySelectorAll('.tab-pane');

  tabButtons.forEach(btn => btn.classList.remove('active'));
  tabPanes.forEach(pane => pane.classList.remove('active'));

  // 選択されたタブにactiveクラスを追加
  const selectedBtn = document.querySelector(`.tab-btn[data-tab="${tabId}"]`);
  const selectedPane = document.getElementById(`tab-${tabId}`);

  if (selectedBtn) selectedBtn.classList.add('active');
  if (selectedPane) selectedPane.classList.add('active');

  activeTab = tabId;

  // ボタンの有効/無効を更新
  updateButtonStates();
}

// ボタンの有効/無効を更新
function updateButtonStates() {
  // 操作ボタンを表示していないため何もしない
}

// デザイン編集モーダルを閉じる
function closeDesignEditModal() {
  const modal = document.getElementById('designEditModal');
  modal.classList.remove('show');
  currentEditingGroupId = null;
  tempDesigns = [];
}

// 編集するグループを読み込む
function loadGroupForEditing(groupId) {
  if (!groupId) {
    return;
  }

  currentEditingGroupId = groupId;

  // グループを取得
  const group = designGroups.find(g => g.id === groupId);

  if (!group) return;

  // グループ名を入力フィールドに設定
  const groupNameInput = document.getElementById('groupNameInput');
  if (groupNameInput) {
    groupNameInput.value = group.name;
  }

  // デザインをコピー
  tempDesigns = JSON.parse(JSON.stringify(group.designs || []));

  // デザイン一覧を表示
  renderDesignsForEdit();
}

// 編集用デザイン一覧を表示
function renderDesignsForEdit() {
  const container = document.getElementById('designsContainer');
  const countSpan = document.getElementById('designCount');

  countSpan.textContent = tempDesigns.length;
  container.innerHTML = '';

  tempDesigns.forEach((design, index) => {
    const designItem = document.createElement('div');
    designItem.className = 'design-edit-item';
    designItem.innerHTML = `
      <div class="design-edit-header">
        <span class="design-number">#${index + 1}</span>
        <button class="delete-design-btn" data-index="${index}">🗑️ 削除</button>
      </div>
      <div class="design-edit-form">
        <div class="form-row">
          <div class="form-group">
            <label>ID:</label>
            <input type="text" class="design-id" value="${design.id || ''}" placeholder="例: modern" data-index="${index}">
          </div>
          <div class="form-group">
            <label>名前:</label>
            <input type="text" class="design-name" value="${design.name || ''}" placeholder="例: モダン風" data-index="${index}">
          </div>
        </div>
        <div class="form-group">
          <label>デフォルトアスペクト比:</label>
          <select class="design-aspect-ratio" data-index="${index}">
            <option value="21:9" ${(design.aspectRatio || '16:9') === '21:9' ? 'selected' : ''}>21:9</option>
            <option value="16:9" ${(design.aspectRatio || '16:9') === '16:9' ? 'selected' : ''}>16:9</option>
            <option value="3:2" ${(design.aspectRatio || '16:9') === '3:2' ? 'selected' : ''}>3:2</option>
            <option value="4:3" ${(design.aspectRatio || '16:9') === '4:3' ? 'selected' : ''}>4:3</option>
            <option value="5:4" ${(design.aspectRatio || '16:9') === '5:4' ? 'selected' : ''}>5:4</option>
            <option value="1:1" ${(design.aspectRatio || '16:9') === '1:1' ? 'selected' : ''}>1:1</option>
            <option value="4:5" ${(design.aspectRatio || '16:9') === '4:5' ? 'selected' : ''}>4:5</option>
            <option value="3:4" ${(design.aspectRatio || '16:9') === '3:4' ? 'selected' : ''}>3:4</option>
            <option value="2:3" ${(design.aspectRatio || '16:9') === '2:3' ? 'selected' : ''}>2:3</option>
            <option value="9:16" ${(design.aspectRatio || '16:9') === '9:16' ? 'selected' : ''}>9:16</option>
          </select>
        </div>
        <div class="form-group">
          <label>参考画像:</label>
          <div class="image-upload-area" data-index="${index}">
            ${design.sampleImage && design.sampleImage !== null ? `
              <div class="image-preview-wrapper">
                <img src="${design.sampleImage}" alt="サンプル画像" class="preview-image">
                <button class="remove-image-btn" data-index="${index}" title="画像を削除">&times;</button>
              </div>
            ` : `<img src="design/no_sample_image.jpg" alt="サンプル画像なし" class="preview-image">`}
            <div class="drop-zone ${design.sampleImage && design.sampleImage !== null ? 'has-image' : ''}" data-index="${index}">
              <p>画像をドラッグ＆ドロップ<br>または<br>クリックして選択</p>
              <input type="file" class="file-input" accept="image/*" data-index="${index}" style="display: none;">
            </div>
          </div>
        </div>
        <div class="form-group">
          <label>プロンプト:</label>
          <textarea class="design-prompt" rows="4" placeholder="デザインの説明..." data-index="${index}">${design.prompt || ''}</textarea>
        </div>
      </div>
    `;
    container.appendChild(designItem);

    // イベントリスナーを設定
    setupDesignEditListeners(designItem, index);
  });
}

// デザイン編集アイテムのイベントリスナーを設定
function setupDesignEditListeners(item, index) {
  // 削除ボタン
  const deleteBtn = item.querySelector('.delete-design-btn');
  deleteBtn.addEventListener('click', () => {
    if (confirm('このデザインを削除しますか？')) {
      tempDesigns.splice(index, 1);
      renderDesignsForEdit();
    }
  });

  // ID入力
  const idInput = item.querySelector('.design-id');
  idInput.addEventListener('input', (e) => {
    tempDesigns[index].id = e.target.value;
  });

  // 名前入力
  const nameInput = item.querySelector('.design-name');
  nameInput.addEventListener('input', (e) => {
    tempDesigns[index].name = e.target.value;
  });

  // プロンプト入力
  const promptInput = item.querySelector('.design-prompt');
  promptInput.addEventListener('input', (e) => {
    tempDesigns[index].prompt = e.target.value;
  });

  // アスペクト比入力
  const aspectRatioInput = item.querySelector('.design-aspect-ratio');
  aspectRatioInput.addEventListener('change', (e) => {
    tempDesigns[index].aspectRatio = e.target.value;
  });

  // ドロップゾーン
  const dropZone = item.querySelector('.drop-zone');
  const fileInput = item.querySelector('.file-input');

  dropZone.addEventListener('click', () => {
    fileInput.click();
  });

  dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('dragover');
  });

  dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('dragover');
  });

  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('dragover');

    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleImageUpload(files[0], index);
    }
  });

  fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
      handleImageUpload(e.target.files[0], index);
    }
  });

  // 画像削除ボタン
  const removeImageBtn = item.querySelector('.remove-image-btn');
  if (removeImageBtn) {
    removeImageBtn.addEventListener('click', (e) => {
      e.stopPropagation(); // ドロップゾーンのクリックイベントを防ぐ
      if (confirm('画像を削除しますか？')) {
        tempDesigns[index].sampleImage = null;
        renderDesignsForEdit();
      }
    });
  }
}

// 画像アップロード処理
async function handleImageUpload(file, index) {
  if (!file.type.startsWith('image/')) {
    alert('画像ファイルを選択してください');
    return;
  }

  try {
    // 画像をリサイズしてBase64に変換（最大2000x2000、品質85%）
    const resizedBase64 = await resizeImageToBase64(file, 2000, 2000, 0.85);
    tempDesigns[index].sampleImage = resizedBase64;
    renderDesignsForEdit();
  } catch (error) {
    console.error('画像のリサイズに失敗:', error);
    alert('画像のアップロードに失敗しました');
  }
}

// デザインを追加
function addDesignToEdit() {
  if (tempDesigns.length >= 32) {
    alert('デザインは最大32個までです');
    return;
  }

  const newDesign = {
    id: '',
    name: '',
    sampleImage: '',
    aspectRatio: '16:9',
    prompt: ''
  };

  tempDesigns.push(newDesign);
  renderDesignsForEdit();
}

// デザイン編集を保存
function saveDesignEdits() {
  if (!currentEditingGroupId) return;

  // グループ名のバリデーション
  const groupNameInput = document.getElementById('groupNameInput');
  const newGroupName = groupNameInput ? groupNameInput.value.trim() : '';

  if (!newGroupName) {
    alert('グループ名を入力してください');
    return;
  }

  // バリデーション
  for (let i = 0; i < tempDesigns.length; i++) {
    const design = tempDesigns[i];
    if (!design.id || !design.name || !design.prompt) {
      alert(`デザイン #${i + 1}: ID、名前、プロンプトは必須です`);
      return;
    }
  }

  // ID重複チェック
  const designIds = tempDesigns.map(d => d.id);
  const uniqueIds = new Set(designIds);
  if (uniqueIds.size !== designIds.length) {
    const duplicateIds = designIds.filter((id, idx) => designIds.indexOf(id) !== idx);
    const uniqueDuplicates = [...new Set(duplicateIds)];
    showToast(`IDが重複しています: ${uniqueDuplicates.join(', ')}\n各デザインのIDは一意である必要があります。`);
    return;
  }

  // グループを更新
  const group = designGroups.find(g => g.id === currentEditingGroupId);
  if (group) {
    group.name = newGroupName;
    group.designs = tempDesigns;
  }

  // 編集していたグループのIDを保存
  const editedGroupId = currentEditingGroupId;

  saveDesignGroups();
  renderDesignGroups();
  closeDesignEditModal();

  // 編集していたタブに切り替え
  switchTab(editedGroupId);

  showToast('デザインを保存しました');
}

// デザイングループをインポート
function importDesignGroup() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.zip';

  input.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    try {
      // zipファイルを読み込む
      const zip = await JSZip.loadAsync(file);

      // design.jsonを取得
      const designJsonFile = zip.file('design.json');
      if (!designJsonFile) {
        showToast('design.jsonが見つかりません');
        return;
      }

      const text = await designJsonFile.async('text');
      const data = JSON.parse(text);

      // バリデーション
      if (!data.name || !Array.isArray(data.designs)) {
        showToast('無効なファイル形式です');
        return;
      }

      // 画像を読み込んでBase64に変換（リサイズ付き）
      const designs = [];
      for (const design of data.designs) {
        const designCopy = { ...design };

        // 画像がある場合、zipから読み込む
        if (design.sampleImage && design.sampleImage.startsWith('images/')) {
          const imagePath = design.sampleImage;
          const imageFile = zip.file(imagePath);

          if (imageFile) {
            const imageBlob = await imageFile.async('blob');

            // Blobをファイルとして扱ってリサイズ
            const file = new File([imageBlob], 'image.jpg', { type: imageBlob.type });
            try {
              const resizedBase64 = await resizeImageToBase64(file, 800, 800, 0.85);
              designCopy.sampleImage = resizedBase64;
            } catch (error) {
              console.error('画像のリサイズに失敗:', error);
              designCopy.sampleImage = '';
            }
          } else {
            designCopy.sampleImage = '';
          }
        }

        designs.push(designCopy);
      }

      // 新しいIDを生成
      const newGroup = {
        id: `group-${Date.now()}`,
        name: data.name,
        designs: designs
      };

      designGroups.push(newGroup);
      saveDesignGroups();
      renderDesignGroups();

      showToast(`「${newGroup.name}」をインポートしました`);
      switchTab(newGroup.id);

    } catch (error) {
      console.error('Import error:', error);
      showToast('インポートに失敗しました: ' + error.message);
    }
  });

  input.click();
}

// デザイングループをエクスポート
async function exportDesignGroup() {
  // 現在はエクスポートボタンを表示していないため何もしない
}

// イベントリスナーの設定（初回のみ）
let eventListenersSetup = false;

function setupEventListeners() {
  if (eventListenersSetup) return;
  eventListenersSetup = true;

  // テキストエリアの文字数カウント
  pageContentTextarea.addEventListener('input', updateCharCount);

  // 生成ボタン（イベント委譲を使用）
  document.addEventListener('click', (e) => {
    if (e.target.classList.contains('generate-btn')) {
      handleStyleSelection(e.target);
    }
  });

  // API設定モーダル
  // 更新チェックボタン
  checkUpdateBtn.addEventListener('click', () => {
    window.open('https://mangax.fomusglobal.com/download', '_blank');
  });

  apiSettingsBtn.addEventListener('click', openApiModal);
  closeModal.addEventListener('click', closeApiModal);
  cancelApiBtn.addEventListener('click', closeApiModal);
  saveApiBtn.addEventListener('click', saveApiKey);

  // 画像拡大モーダル
  imageModal.addEventListener('click', closeImageModal);

  // APIモーダルの外側をクリックしたら閉じる
  window.addEventListener('click', (e) => {
    if (e.target === apiModal) {
      closeApiModal();
    }
  });

  // 原作アップロード機能
  setupNovelUpload();

  // 画像アップロード機能の初期化
  setupImageUpload();
}

// APIキーの読み込み
async function loadApiKey() {
  const result = await chrome.storage.local.get('falApiKey');
  if (result.falApiKey) {
    falApiKey = result.falApiKey;
  }
}

// APIモーダルを開く
function openApiModal() {
  apiKeyInput.value = falApiKey || '';
  apiModal.classList.add('show');
}

// APIモーダルを閉じる
function closeApiModal() {
  apiModal.classList.remove('show');
}

// 画像拡大モーダルを開く
function openImageModal(imageUrl) {
  modalImage.src = imageUrl;
  imageModal.style.display = 'flex';
}

// 画像拡大モーダルを閉じる
function closeImageModal() {
  imageModal.style.display = 'none';
}

// APIキーを保存
async function saveApiKey() {
  const newApiKey = apiKeyInput.value.trim();
  if (!newApiKey) {
    alert('APIキーを入力してください');
    return;
  }

  falApiKey = newApiKey;
  await chrome.storage.local.set({ falApiKey: newApiKey });
  alert('APIキーを保存しました');
  closeApiModal();
}

// サンプル画像のクリックイベントを設定
// サンプル画像クリックイベント（初回のみ、イベント委譲を使用）
let sampleImageListenerSetup = false;

function setupSampleImageClickEvents() {
  if (sampleImageListenerSetup) return;
  sampleImageListenerSetup = true;

  document.addEventListener('click', (e) => {
    if (e.target.tagName === 'IMG' && e.target.closest('.sample-image')) {
      openImageModal(e.target.src);
    }
  });
}

// 文字数カウントの更新
function updateCharCount() {
  const count = pageContentTextarea.value.length;
  charCountSpan.textContent = count.toLocaleString();
}

// スタイル選択の処理
let currentAbortController = null;

async function handleStyleSelection(button) {
  const style = button.dataset.style;
  const groupId = button.dataset.group || 'home';
  const displayContainerId = groupId === 'home' ? `design-${style}` : `design-${groupId}-${style}`;
  const displayContainer = document.getElementById(displayContainerId);
  const designArea = button.closest('.design-area');
  const downloadBtn = designArea.querySelector('.download-btn');
  const copyBtn = designArea.querySelector('.copy-btn');

  // アスペクト比を取得
  const aspectRatioSelect = designArea.querySelector('.aspect-ratio-select');
  const aspectRatio = aspectRatioSelect ? aspectRatioSelect.value : '16:9';

  // 元のボタンテキストを保存
  const originalText = button.textContent;

  // ボタンを「キャンセル」に変更
  button.textContent = 'キャンセル';
  button.classList.add('cancel-btn');

  // 生成中の画像要素を取得
  const generatedImageWrapper = displayContainer.querySelector('.generated-image');

  // ローディング表示を生成画像の上に追加
  const loadingDiv = document.createElement('div');
  loadingDiv.className = 'design-loading';
  loadingDiv.innerHTML = '<div class="design-spinner"></div><div class="design-loading-text">生成中...</div>';
  generatedImageWrapper.appendChild(loadingDiv);

  // AbortControllerを作成
  currentAbortController = new AbortController();
  const abortSignal = currentAbortController.signal;

  // キャンセルボタンのクリックイベント
  const cancelHandler = () => {
    if (currentAbortController) {
      currentAbortController.abort();
      currentAbortController = null;
    }
  };
  button.addEventListener('click', cancelHandler, { once: true });

  const isMultiPageManga = style === 'kuku_manga_x10' || style === 'kuku_manga_x3';
  const totalPages = style === 'kuku_manga_x10' ? 10 : (style === 'kuku_manga_x3' ? 3 : null);

  try {
    let imageUrl = '';

    if (isMultiPageManga) {
      const pageContents = splitContentByPages(totalPages, pageContentTextarea.value);
      const pages = [];
      for (let i = 0; i < totalPages; i++) {
        if (loadingDiv.querySelector('.design-loading-text')) {
          loadingDiv.querySelector('.design-loading-text').textContent = `生成中... (${i + 1}/${totalPages})`;
        }
        const url = await generateThumbnail(style, groupId, aspectRatio, abortSignal, pageContents[i] || '', i + 1, totalPages);
        pages.push(url);
      }

      // ローディング表示を削除
      generatedImageWrapper.removeChild(loadingDiv);

      renderMultiPageResult(generatedImageWrapper, pages);

      if (!generatedImages[style]) {
        generatedImages[style] = [];
      }
      generatedImages[style] = pages;

      downloadBtn.disabled = false;
      copyBtn.disabled = false;
      downloadBtn.onclick = () => downloadMultipleImages(pages, style);
      copyBtn.onclick = () => copyImageToClipboard(pages[pages.length - 1]);
      return;
    }

    // 単ページ生成
    imageUrl = await generateThumbnail(style, groupId, aspectRatio, abortSignal);

    // ローディング表示を削除
    generatedImageWrapper.removeChild(loadingDiv);

    // 生成された画像に入れ替え
    if (generatedImageWrapper) {
      const img = generatedImageWrapper.querySelector('img');
      img.src = imageUrl;
      img.alt = `${style}スタイルのデザイン`;
      img.addEventListener('click', () => openImageModal(imageUrl));
    }

    // 生成画像を保存
    if (!generatedImages[style]) {
      generatedImages[style] = [];
    }
    generatedImages[style].push(imageUrl);

    // ダウンロード・コピーボタンを有効化し、最新画像に対応
    downloadBtn.disabled = false;
    copyBtn.disabled = false;

    downloadBtn.onclick = () => downloadImage(imageUrl, style);
    copyBtn.onclick = () => copyImageToClipboard(imageUrl);

  } catch (error) {
    // ローディング表示を削除
    if (generatedImageWrapper.contains(loadingDiv)) {
      generatedImageWrapper.removeChild(loadingDiv);
    }

    // キャンセルされた場合
    if (error.name === 'AbortError') {
      const messageDiv = document.createElement('div');
      messageDiv.className = 'design-loading';
      messageDiv.style.cursor = 'default';
      messageDiv.innerHTML = `
        <div style="color: #95a5a6; font-size: 14px; font-weight: bold;">🚫 キャンセルしました</div>
        <div style="color: #7f8c8d; font-size: 12px; margin-top: 8px;">画像生成をキャンセルしました</div>
      `;
      generatedImageWrapper.appendChild(messageDiv);

      setTimeout(() => {
        if (generatedImageWrapper.contains(messageDiv)) {
          generatedImageWrapper.removeChild(messageDiv);
        }
      }, 3000);
    } else {
      // タイムアウトまたはエラーメッセージを表示
      const messageDiv = document.createElement('div');
      messageDiv.className = 'design-loading';
      messageDiv.style.cursor = 'default';

      if (error.message && error.message.includes('タイムアウト')) {
        messageDiv.innerHTML = `
          <div style="color: #e67e22; font-size: 14px; font-weight: bold;">⏱️ タイムアウトしました</div>
          <div style="color: #7f8c8d; font-size: 12px; margin-top: 8px;">画像生成に時間がかかっています。もう一度「生成」ボタンを押してください。</div>
        `;
      } else {
        messageDiv.innerHTML = `
          <div style="color: #e74c3c; font-size: 14px; font-weight: bold;">❌ 生成に失敗しました</div>
          <div style="color: #7f8c8d; font-size: 12px; margin-top: 8px;">もう一度「生成」ボタンを押してください</div>
        `;
      }

      generatedImageWrapper.appendChild(messageDiv);

      // 10秒後にメッセージを削除（タイムアウトの場合は長めに表示）
      const displayTime = error.message && error.message.includes('タイムアウト') ? 10000 : 5000;
      setTimeout(() => {
        if (generatedImageWrapper.contains(messageDiv)) {
          generatedImageWrapper.removeChild(messageDiv);
        }
      }, displayTime);
    }
  } finally {
    // ボタンを元に戻す
    button.textContent = originalText;
    button.classList.remove('cancel-btn');
    button.disabled = false;
    currentAbortController = null;
  }
}

// サムネイル生成
async function generateThumbnail(style, groupId = 'home', aspectRatio = '16:9', abortSignal = null, pageTextOverride = null, pageNumber = null, totalPages = null) {
  // 画像生成API呼び出し
  const imageUrl = await callImageGenerationAPI(style, groupId, aspectRatio, abortSignal, pageTextOverride, pageNumber, totalPages);

  return imageUrl;
}

// 画像生成API呼び出し
async function callImageGenerationAPI(style, groupId = 'home', aspectRatio = '16:9', abortSignal = null, pageTextOverride = null, pageNumber = null, totalPages = null) {
  console.log('Generating image with style:', style, 'groupId:', groupId, 'aspectRatio:', aspectRatio);

  // APIキーのチェック
  if (!falApiKey) {
    throw new Error('FAL APIキーが設定されていません。API設定から設定してください。');
  }

  // タイトルとページ内容を取得
  const title = titleInput && titleInput.value ? titleInput.value.trim() : '';
  const content = pageTextOverride !== null ? pageTextOverride : pageContentTextarea.value;

  // プロンプトを取得
  let stylePrompt = '';

  if (groupId === 'home') {
    // ホームタブの場合はデフォルトのデザイン設定から取得
    const designs = designConfig.designs || designConfig.styles || [];
    const styleConfig = designs.find(s => s.id === style);
    stylePrompt = styleConfig ? styleConfig.prompt : '';
  } else {
    // カスタムグループの場合はグループのデザイン設定から取得
    const group = designGroups.find(g => g.id === groupId);
    if (group && group.designs) {
      const design = group.designs.find(d => d.id === style);
      stylePrompt = design ? design.prompt : '';
    }
  }

  // プロンプトを生成（タイトルと記事本文を含める）
  let fullPrompt = stylePrompt;

  // キャラクターシートを追加（マンガ系のみ）
  const isMangaStyle = (style || '').toLowerCase().includes('manga');
  const characterSheet = characterImages.filter(c => c.name || c.base64);
  if (isMangaStyle && characterSheet.length > 0) {
    fullPrompt += '\n\nキャラクターシート:';
    characterSheet.forEach((c, idx) => {
      fullPrompt += `\n- ${c.name && c.name.trim() !== '' ? c.name.trim() : `キャラクター${idx + 1}`} ${c.base64 ? '(参考画像あり: 必ず外見を揃える)' : ''}`;
    });
    fullPrompt += '\nルール: 吹き出し内にキャラクター名は入れない。ナレーションは白い四角枠で配置。オノマトペとSEは「ページ内容」に書かれたものだけを使い、勝手に追加しない。';
  }

  // コンテンツ処理の指示を追加
  fullPrompt += '\n\nContent Guidelines:';
  fullPrompt += '\n- Focus on the core topic and main message from the article';
  fullPrompt += '\n- Include dates ONLY if they are central to the story (e.g., historical events, commemorations, time-sensitive announcements)';
  fullPrompt += '\n- Exclude irrelevant metadata like publication dates, last updated timestamps, author names, or page numbers';
  fullPrompt += '\n- DO NOT include temporal/dimensional information such as: "today\'s date" (今日の日付), "article count" (残り記事数), "reading time estimates", "view counts", "share counts", or similar statistics';
  fullPrompt += '\n- Extract and emphasize the key points that would attract viewers';

  fullPrompt += '\n\n';

  if (pageNumber !== null && totalPages !== null) {
    fullPrompt += `この画像はページ ${pageNumber}/${totalPages} に対応します。このページ分の内容のみ描いてください。シーンの区切りやページ割りを意識し、他ページの内容は含めないでください。\n\n`;
  }

  // 原作テキストを付与（長すぎる場合は先頭を使用）
  if (novelContent && novelContent.trim() !== '') {
    // プロンプトに入れる原作テキストは長すぎるとエラーになるので短く抑える
    const NOVEL_SNIPPET_LIMIT = 8000;
    const snippet = novelContent.slice(0, NOVEL_SNIPPET_LIMIT);
    fullPrompt += '原作テキスト（抜粋）:\n' + snippet + '\n\n';
    fullPrompt += '上記の原作設定・世界観・時系列を一貫させ、各ページで背景やキャラクターの外見・位置関係が自然に繋がるように描いてください。\n\n';
  }

  if (title) {
    fullPrompt += `タイトル: ${title}\n\n`;
  }

  fullPrompt += `記事本文:\n${content.substring(0, 2000)}`;

  // アスペクト比はパラメータから取得（aspectRatio変数は既に存在）

  // サンプル画像のパスを取得
  let sampleImagePath = '';
  if (groupId === 'home') {
    const designs = (designConfig && (designConfig.designs || designConfig.styles)) || [];
    const styleConfig = designs.find(s => s.id === style);
    sampleImagePath = styleConfig ? styleConfig.sampleImage : '';
  } else {
    const groups = designGroups || [];
    const group = groups.find(g => g.id === groupId);
    if (group && group.designs) {
      const design = group.designs.find(d => d.id === style);
      sampleImagePath = design ? design.sampleImage : '';
    } else {
      sampleImagePath = '';
    }
  }

  // 参考画像の有無を判定してeditエンドポイントを使用するか決定
  let useEditEndpoint = false;
  const imageUrls = [];

  const characterImageData = characterImages.filter(img => !!img.base64);

  console.log('=== 画像アップロード処理開始 ===');
  console.log('サンプル画像パス:', sampleImagePath);
  console.log('キャラクター画像数:', characterImageData.length);

  // サンプル画像またはキャラクター画像がある場合はeditエンドポイントを使用
  // nullの場合は画像なしとして扱う
  const hasAnyImage = (sampleImagePath && sampleImagePath !== null) || characterImageData.length > 0;

  if (hasAnyImage) {
    useEditEndpoint = true;
    console.log('参考画像が存在するため、editエンドポイントを使用します');

    // サンプル画像を最初に追加（スタイルの基準として）
    // nullの場合はスキップ
    if (sampleImagePath && sampleImagePath !== null) {
      try {
        console.log('サンプル画像を処理中:', sampleImagePath);

        // Base64データURIに変換
        let sampleImageDataUri;
        if (sampleImagePath.startsWith('data:')) {
          console.log('サンプル画像はすでにBase64データURIです');
          sampleImageDataUri = sampleImagePath;
        } else {
          console.log('サンプル画像をBase64データURIに変換します');
          sampleImageDataUri = await convertImageToBase64(sampleImagePath);
        }

        if (sampleImageDataUri) {
          // FAL CDNにアップロードを試行
          const uploadResult = await uploadToFalCDN(sampleImageDataUri, 'sample.jpg');

          if (uploadResult.url) {
            console.log('✓ サンプル画像をFAL CDNにアップロード成功:', uploadResult.url);
            imageUrls.push(uploadResult.url);
          } else {
            console.warn('⚠ FAL CDNアップロード失敗、Base64にフォールバック');
            imageUrls.push(sampleImageDataUri);
          }
        } else {
          console.warn('⚠ サンプル画像の変換に失敗しました');
        }
      } catch (error) {
        console.error('✗ サンプル画像の処理に失敗しました:', error);
        console.error('エラー詳細:', error.message);
      }
    }

    // キャラクター画像を追加
    if (characterImageData.length > 0) {
      for (let i = 0; i < characterImageData.length; i++) {
        const base64 = characterImageData[i].base64;
        try {
          console.log(`キャラクター画像を処理中 (${i + 1}/${characterImageData.length})`);

          const uploadResult = await uploadToFalCDN(base64, `character-${i + 1}.jpg`);

          if (uploadResult.url) {
            console.log(`✓ キャラクター画像をFAL CDNにアップロード成功 (${i + 1}):`, uploadResult.url);
            imageUrls.push(uploadResult.url);
          } else {
            console.warn(`⚠ FAL CDNアップロード失敗 (${i + 1})、Base64にフォールバック`);
            imageUrls.push(base64);
          }
        } catch (error) {
          console.error(`✗ キャラクター画像の処理に失敗 (${i + 1})、Base64を使用:`, error);
          imageUrls.push(base64);
        }
      }
    }

    console.log('=== 画像アップロード処理完了 ===');
    console.log('アップロードされた画像数:', imageUrls.length);
    console.log('画像URLs:', imageUrls);
  } else {
    console.log('参考画像がないため、通常のエンドポイントを使用します');
  }

  // APIリクエストボディの構築
  const requestBody = {
    prompt: fullPrompt,
    num_images: 1,
    aspect_ratio: aspectRatio,
    output_format: 'jpeg',
    resolution: '1K'
  };

  // 参考画像がある場合は追加（image_urlsパラメータを使用）
  if (useEditEndpoint && imageUrls.length > 0) {
    requestBody.image_urls = imageUrls;

    // プロンプトに参考画像の指示を追加
    let imageInstructions = '\n\n参考画像の使用指示:';

    // サンプル画像の指示（スタイルのベースとなる画像）
    // nullの場合はスキップ
    if (sampleImagePath && sampleImagePath !== null) {
      imageInstructions += '\n- Sample image (1st image): Use this as a comprehensive style reference. IMPORTANT: Match the overall atmosphere, composition, layout structure, text amount and placement, visual hierarchy, graphic element styles, and design patterns. However, DO NOT create an exact copy - maintain originality by using the specified theme color, adapting the content to the article topic, and creating unique visual elements while preserving the same design language and aesthetic feel. Think of it as creating a design in the same style and mood, not duplicating the reference.';
    }

    // キャラクター画像の指示
    if (characterImageData.length > 0) {
      imageInstructions += '\n- Character images: Include every provided character (up to 5). Keep each character\'s design and features accurate while matching expressions/poses to the article mood.';
    }

    requestBody.prompt += imageInstructions;
  }

  // 使用するAPIエンドポイントを決定
  const apiEndpoint = useEditEndpoint
    ? 'https://queue.fal.run/fal-ai/nano-banana-pro/edit'
    : 'https://queue.fal.run/fal-ai/nano-banana-pro';

  console.log('=== API リクエスト情報 ===');
  console.log('サンプル画像パス:', sampleImagePath);
  console.log('editエンドポイント使用:', useEditEndpoint);
  console.log('使用するエンドポイント:', apiEndpoint);
  console.log('参考画像数:', imageUrls.length);
  if (imageUrls.length > 0) {
    console.log('画像URL:', imageUrls);
  }
  console.log('リクエストボディ:', JSON.stringify(requestBody, null, 2));
  console.log('image_urlsパラメータが含まれているか:', 'image_urls' in requestBody);
  if ('image_urls' in requestBody) {
    console.log('image_urlsの内容:', requestBody.image_urls);
  }

  // FAL AI APIを呼び出す
  try {
    const fetchOptions = {
      method: 'POST',
      headers: {
        'Authorization': `Key ${falApiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody)
    };

    // AbortSignalを追加
    if (abortSignal) {
      fetchOptions.signal = abortSignal;
    }

    const response = await fetch(apiEndpoint, fetchOptions);

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(`API Error: ${response.status} - ${errorData.detail || response.statusText}`);
    }

    const data = await response.json();
    console.log('FAL API Response:', data);

    // request_idを取得
    const requestId = data.request_id;
    const statusUrl = data.status_url || `${apiEndpoint}/requests/${requestId}/status`;
    const resultUrl = data.response_url || `${apiEndpoint}/requests/${requestId}`;

    console.log('Polling URLs:', {
      requestId,
      statusUrl,
      resultUrl
    });

    // ポーリングで結果を取得
    const result = await pollForResult(requestId, statusUrl, resultUrl, abortSignal);

    // 画像URLを返す
    if (result.images && result.images.length > 0) {
      return result.images[0].url;
    } else {
      throw new Error('画像の生成に失敗しました');
    }

  } catch (error) {
    console.error('FAL API Error:', error);
    throw error;
  }
}

// 結果をポーリングで取得（app.jsの実装を参考）
async function pollForResult(requestId, statusUrl, resultUrl, abortSignal = null) {
  console.log(`FAL AIキューからの結果取得を開始: request_id: ${requestId}`);

  const maxRetries = 60; // 最大60回（5秒 × 60 = 5分）
  const retryInterval = 5000; // 5秒ごと

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      // キャンセルチェック
      if (abortSignal && abortSignal.aborted) {
        throw new DOMException('キャンセルされました', 'AbortError');
      }

      // 5秒待機
      await new Promise(resolve => setTimeout(resolve, retryInterval));

      // 待機後もキャンセルチェック
      if (abortSignal && abortSignal.aborted) {
        throw new DOMException('キャンセルされました', 'AbortError');
      }

      console.log(`ステータス確認 (試行 ${attempt + 1}/${maxRetries}): ${statusUrl}`);

      // ステータスをチェック
      const statusFetchOptions = {
        headers: {
          'Authorization': `Key ${falApiKey}`
        }
      };

      // AbortSignalを追加
      if (abortSignal) {
        statusFetchOptions.signal = abortSignal;
      }

      const statusResponse = await fetch(statusUrl, statusFetchOptions);

      if (!statusResponse.ok) {
        throw new Error(`Status check failed: ${statusResponse.status}`);
      }

      const statusData = await statusResponse.json();
      console.log('Status check response:', {
        status: statusData.status,
        hasImages: !!(statusData.images && statusData.images.length > 0),
        attempt: attempt + 1
      });

      // COMPLETEDの場合
      if (statusData.status === 'COMPLETED') {
        // まずstatusDataにimagesがあるか確認
        if (statusData.images && statusData.images.length > 0) {
          console.log('✓ Result found in status response, returning directly');
          return statusData;
        }

        // statusDataにimagesがない場合、resultUrlから取得
        console.log('Fetching result from:', resultUrl);
        try {
          const resultFetchOptions = {
            headers: {
              'Authorization': `Key ${falApiKey}`
            }
          };

          // AbortSignalを追加
          if (abortSignal) {
            resultFetchOptions.signal = abortSignal;
          }

          const resultResponse = await fetch(resultUrl, resultFetchOptions);

          console.log('Result fetch response status:', resultResponse.status);

          if (!resultResponse.ok) {
            console.warn(`⚠ Result fetch failed with status ${resultResponse.status}`);
            // result取得失敗でもstatusDataがあれば使用
            if (statusData) {
              console.log('Using statusData as fallback (response not ok)');
              return statusData;
            }
            throw new Error(`Result fetch failed: ${resultResponse.status}`);
          }

          const result = await resultResponse.json();
          console.log('✓ Result fetched successfully:', {
            hasImages: !!(result.images && result.images.length > 0),
            hasData: !!(result.data)
          });
          return result;
        } catch (resultError) {
          console.error('✗ Result fetch error:', resultError);
          // result取得エラーでもstatusDataがあれば使用
          if (statusData) {
            console.log('Using statusData as fallback (error caught)');
            return statusData;
          }
          throw resultError;
        }
      } else if (statusData.status === 'FAILED') {
        throw new Error(statusData.error || '画像生成に失敗しました');
      }

      // 進捗表示（ログがある場合）
      if (statusData.logs && statusData.logs.length > 0) {
        const lastLog = statusData.logs[statusData.logs.length - 1];
        console.log(`生成中: ${lastLog.message || '処理中...'}`);
      }

    } catch (error) {
      // 最後の試行でない場合は再試行
      if (attempt < maxRetries - 1) {
        continue;
      }

      throw error;
    }
  }

  throw new Error('タイムアウト: 画像生成に時間がかかりすぎています');
}

// 画像をダウンロード
async function downloadImage(imageUrl, style) {
  try {
    const response = await fetch(imageUrl);
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = `design-${style}-${Date.now()}.jpg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);

    showToast('画像をダウンロードしました');
  } catch (error) {
    console.error('Download error:', error);
    showToast('ダウンロードに失敗しました: ' + error.message);
  }
}

// 複数画像をダウンロード（zip）
async function downloadMultipleImages(imageUrls, style) {
  try {
    const zip = new JSZip();
    for (let i = 0; i < imageUrls.length; i++) {
      const response = await fetch(imageUrls[i]);
      const blob = await response.blob();
      zip.file(`design-${style}-page${i + 1}.jpg`, blob);
    }

    const zipBlob = await zip.generateAsync({ type: 'blob' });
    const url = window.URL.createObjectURL(zipBlob);

    const a = document.createElement('a');
    a.href = url;
    a.download = `design-${style}-${Date.now()}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);

    showToast('10ページ分の画像をダウンロードしました');
  } catch (error) {
    console.error('Multi download error:', error);
    showToast('ダウンロードに失敗しました: ' + error.message);
  }
}

function renderMultiPageResult(wrapper, imageUrls) {
  wrapper.innerHTML = '';
  const grid = document.createElement('div');
  grid.className = 'multi-page-grid';

  imageUrls.forEach((url, idx) => {
    const item = document.createElement('div');
    item.className = 'multi-page-item';
    item.innerHTML = `
      <div class="multi-page-label">Page ${idx + 1}</div>
      <div class="design-wrapper generated-image">
        <img src="${url}" alt="Page ${idx + 1}">
      </div>
    `;
    item.querySelector('img').addEventListener('click', () => openImageModal(url));
    grid.appendChild(item);
  });

  wrapper.appendChild(grid);
}

// ページ内容をページ数に合わせて分割
function splitContentByPages(totalPages, rawContent) {
  if (!rawContent || rawContent.trim() === '') {
    return Array.from({ length: totalPages }, () => '');
  }

  const normalized = rawContent.replace(/\r\n/g, '\n');

  // パターン: 行頭に「ページ1」「page1」「Page 1」などがある場合に区切る
  const lines = normalized.split('\n');
  const sections = [];
  let current = [];

  const pageMarkerRegex = /^(?:page|ページ)\s*(\d+)/i;
  lines.forEach((line) => {
    const match = line.trim().match(pageMarkerRegex);
    if (match) {
      if (current.length > 0) {
        sections.push(current.join('\n').trim());
      }
      current = [];
    } else {
      current.push(line);
    }
  });
  if (current.length > 0) {
    sections.push(current.join('\n').trim());
  }

  let pages = [];

  if (sections.length >= totalPages) {
    pages = sections.slice(0, totalPages);
  } else if (sections.length > 0) {
    pages = sections;
  }

  // パターンが見つからなかった場合は段落ベースで均等分割
  if (pages.length === 0) {
    const paragraphs = normalized.split(/\n\s*\n+/).map(p => p.trim()).filter(p => p !== '');
    if (paragraphs.length === 0) {
      return Array.from({ length: totalPages }, () => normalized);
    }
    const chunkSize = Math.max(1, Math.ceil(paragraphs.length / totalPages));
    for (let i = 0; i < totalPages; i++) {
      const chunk = paragraphs.slice(i * chunkSize, (i + 1) * chunkSize).join('\n\n');
      pages.push(chunk || '');
    }
  }

  // ページ数を揃える（足りない分は最後の内容を再利用）
  if (pages.length < totalPages) {
    const last = pages[pages.length - 1] || '';
    while (pages.length < totalPages) {
      pages.push(last);
    }
  } else if (pages.length > totalPages) {
    pages = pages.slice(0, totalPages);
  }

  return pages;
}

// 画像をクリップボードにコピー
async function copyImageToClipboard(imageUrl) {
  try {
    const response = await fetch(imageUrl);
    const blob = await response.blob();

    // PNGに変換してコピー
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();

    img.crossOrigin = 'anonymous';
    img.src = imageUrl;

    await new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = reject;
    });

    canvas.width = img.width;
    canvas.height = img.height;
    ctx.drawImage(img, 0, 0);

    canvas.toBlob(async (pngBlob) => {
      await navigator.clipboard.write([
        new ClipboardItem({
          'image/png': pngBlob
        })
      ]);
      showToast('クリップボードにコピーしました');
    }, 'image/png');

  } catch (error) {
    console.error('Clipboard copy error:', error);
    showToast('クリップボードへのコピーに失敗しました: ' + error.message);
  }
}

// 画像アップロード機能の初期化
function setupImageUpload() {
  initCharacterUploadArea();
}

// 原作アップロード
function setupNovelUpload() {
  if (!novelDropZone || !novelFileInput) return;

  novelDropZone.addEventListener('click', () => {
    novelFileInput.click();
  });

  novelFileInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (file) {
      await handleNovelFile(file);
    }
  });

  novelDropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    novelDropZone.classList.add('dragover');
  });

  novelDropZone.addEventListener('dragleave', (e) => {
    e.preventDefault();
    novelDropZone.classList.remove('dragover');
  });

  novelDropZone.addEventListener('drop', async (e) => {
    e.preventDefault();
    novelDropZone.classList.remove('dragover');
    const file = e.dataTransfer.files[0];
    if (file) {
      await handleNovelFile(file);
    }
  });

  if (removeNovelBtn) {
    removeNovelBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      novelContent = '';
      novelFileName = '';
      await saveNovelContent();
      updateNovelMeta();
      showToast('原作テキストを削除しました');
    });
  }

  updateNovelMeta();
}

async function handleNovelFile(file) {
  if (!file.type.startsWith('text/') && !file.name.match(/\.(txt|md|markdown|json|csv|tsv)$/i)) {
    showToast('テキストファイルをアップロードしてください');
    return;
  }

  try {
    const text = await file.text();
    const MAX_NOVEL_CHARS = 100000;
    novelContent = text.slice(0, MAX_NOVEL_CHARS);
    novelFileName = file.name;
    await saveNovelContent();
    updateNovelMeta();
    showToast(`原作を読み込みました（${novelContent.length.toLocaleString()}文字）`);
  } catch (error) {
    console.error('Failed to read novel file:', error);
    showToast('原作ファイルの読み込みに失敗しました');
  }
}

function updateNovelMeta() {
  if (!novelMeta || !novelFileNameSpan || !novelCharCountSpan) return;

  if (novelContent && novelContent.trim() !== '') {
    novelMeta.style.display = 'flex';
    novelFileNameSpan.textContent = novelFileName || '（ファイル名なし）';
    novelCharCountSpan.textContent = novelContent.length.toLocaleString();
  } else {
    novelMeta.style.display = 'none';
    novelFileNameSpan.textContent = '';
    novelCharCountSpan.textContent = '0';
  }
}

function initCharacterUploadArea() {
  const addBtn = document.getElementById('addCharacterBtn');
  if (!addBtn) return;

  if (characterImages.length === 0) {
    characterImages.push(createEmptyCharacterSlot());
  }

  renderCharacterList();

  addBtn.addEventListener('click', () => {
    if (characterImages.length >= MAX_CHARACTERS) {
      showToast(`キャラクターは最大${MAX_CHARACTERS}人までです`);
      return;
    }
    characterImages.push(createEmptyCharacterSlot());
    renderCharacterList();
    saveCharacterSheet();
  });
}

function createEmptyCharacterSlot() {
  return {
    id: `character-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    name: '',
    base64: null
  };
}

function renderCharacterList() {
  const list = document.getElementById('characterList');
  const addBtn = document.getElementById('addCharacterBtn');
  if (!list) return;

  list.innerHTML = '';

  characterImages.forEach((character, index) => {
    const card = document.createElement('div');
    card.className = 'character-card';
    card.dataset.id = character.id;

    card.innerHTML = `
      <div class="character-card-header">
        <span class="character-label">キャラクター #${index + 1}</span>
        <button class="delete-character-card" data-id="${character.id}" ${characterImages.length === 1 ? 'disabled' : ''}>✕</button>
      </div>
      <input type="text" class="character-name-input" data-id="${character.id}" placeholder="キャラクター名 (任意)" value="${character.name || ''}">
      <div class="image-upload-zone character-upload-zone" data-id="${character.id}">
        <input type="file" class="character-file-input" accept="image/*" style="display: none;" data-id="${character.id}">
        <div class="upload-placeholder" ${character.base64 ? 'style="display: none;"' : ''}>
          <p>📷 画像をドラッグ&ドロップ<br>またはクリックして選択</p>
        </div>
        <img class="preview-img" style="${character.base64 ? '' : 'display: none;'}" src="${character.base64 || ''}" alt="キャラクター画像">
        <button class="remove-image-btn" style="${character.base64 ? '' : 'display: none;'}" data-id="${character.id}">✕ 削除</button>
      </div>
      <button class="library-btn character-library-btn" data-id="${character.id}">📚 ライブラリから選ぶ</button>
    `;

    list.appendChild(card);
  });

  attachCharacterCardEvents();

  if (addBtn) {
    addBtn.disabled = characterImages.length >= MAX_CHARACTERS;
  }
}

function attachCharacterCardEvents() {
  const list = document.getElementById('characterList');
  if (!list) return;

  list.querySelectorAll('.character-upload-zone').forEach(zone => {
    const characterId = zone.dataset.id;
    const input = zone.querySelector('.character-file-input');
    const preview = zone.querySelector('.preview-img');
    const removeBtn = zone.querySelector('.remove-image-btn');
    const nameInput = zone.parentElement.querySelector('.character-name-input');

    zone.addEventListener('click', (e) => {
      if (e.target === removeBtn) return;
      input.click();
    });

    input.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) {
        handleImageFile(file, preview, removeBtn, zone, 'character', characterId);
      }
    });

    zone.addEventListener('dragover', (e) => {
      e.preventDefault();
      zone.classList.add('dragover');
    });

    zone.addEventListener('dragleave', (e) => {
      e.preventDefault();
      zone.classList.remove('dragover');
    });

    zone.addEventListener('drop', (e) => {
      e.preventDefault();
      zone.classList.remove('dragover');

      const file = e.dataTransfer.files[0];
      if (file && file.type.startsWith('image/')) {
        handleImageFile(file, preview, removeBtn, zone, 'character', characterId);
      } else {
        showToast('画像ファイルをドロップしてください');
      }
    });

    if (removeBtn) {
      removeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        removeImage(preview, removeBtn, zone, 'character', characterId);
      });
    }

    if (nameInput) {
      nameInput.addEventListener('input', (e) => {
        updateCharacterName(characterId, e.target.value);
      });
    }
  });

  list.querySelectorAll('.delete-character-card').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const characterId = e.currentTarget.dataset.id;
      if (btn.disabled) return;
      removeCharacterSlot(characterId);
    });
  });

  list.querySelectorAll('.character-library-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const characterId = e.currentTarget.dataset.id;
      openImageLibraryModal({ type: 'character', id: characterId });
    });
  });
}

function removeCharacterSlot(characterId) {
  if (characterImages.length === 1) {
    updateCharacterImage(characterId, null);
  } else {
    characterImages = characterImages.filter(c => c.id !== characterId);
  }
  renderCharacterList();
  showToast('キャラクター枠を削除しました');
  saveCharacterSheet();
}

// 画像アップロードゾーンのイベント設定
function setupImageUploadZone(zone, input, preview, removeBtn, type, targetId = null) {
  if (!zone || !input || !preview || !removeBtn) return;

  // クリックでファイル選択
  zone.addEventListener('click', (e) => {
    if (e.target === removeBtn) return;
    input.click();
  });

  // ファイル選択時の処理
  input.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
      handleImageFile(file, preview, removeBtn, zone, type, targetId);
    }
  });

  // ドラッグオーバー時のスタイル変更
  zone.addEventListener('dragover', (e) => {
    e.preventDefault();
    zone.classList.add('dragover');
  });

  zone.addEventListener('dragleave', (e) => {
    e.preventDefault();
    zone.classList.remove('dragover');
  });

  // ドロップ時の処理
  zone.addEventListener('drop', (e) => {
    e.preventDefault();
    zone.classList.remove('dragover');

    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      handleImageFile(file, preview, removeBtn, zone, type, targetId);
    } else {
      showToast('画像ファイルをドロップしてください');
    }
  });

  // 削除ボタンのイベント
  removeBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    removeImage(preview, removeBtn, zone, type, targetId);
  });
}

// 画像ファイルの処理
async function handleImageFile(file, preview, removeBtn, zone, type, targetId = null) {
  // ファイルサイズチェック（10MB以下）
  if (file.size > 10 * 1024 * 1024) {
    showToast('画像サイズは10MB以下にしてください');
    return;
  }

  try {
    // 画像をリサイズしてBase64に変換（最大2000x2000、品質85%）
    const resizedBase64 = await resizeImageToBase64(file, 2000, 2000, 0.85);

    // プレビュー表示
    preview.src = resizedBase64;
    preview.style.display = 'block';
    removeBtn.style.display = 'block';

    // placeholderを非表示
    const placeholder = zone.querySelector('.upload-placeholder');
    if (placeholder) {
      placeholder.style.display = 'none';
    }

    // Base64データを保存
    if (type === 'character') {
      updateCharacterImage(targetId, resizedBase64);
      renderCharacterList();
      await saveCharacterSheet();
    }

    const characterIndex = type === 'character' ? getCharacterIndex(targetId) : null;
    const targetLabel = type === 'character' && characterIndex !== -1 ? `キャラクター #${characterIndex + 1}` : 'キャラクター';
    showToast(`${targetLabel}画像をアップロードしました（リサイズ済み）`);
  } catch (error) {
    console.error('画像の処理に失敗:', error);
    showToast('画像の読み込みに失敗しました');
  }
}

// 画像の削除
function removeImage(preview, removeBtn, zone, type, targetId = null) {
  preview.style.display = 'none';
  preview.src = '';
  removeBtn.style.display = 'none';

  // placeholderを表示
  const placeholder = zone.querySelector('.upload-placeholder');
  if (placeholder) {
    placeholder.style.display = 'block';
  }

  // Base64データをクリア
  if (type === 'character') {
    updateCharacterImage(targetId, null);
    renderCharacterList();
  }

  // input要素をリセット
  const input = zone.querySelector('input[type="file"]');
  if (input) {
    input.value = '';
  }

  const characterIndex = type === 'character' ? getCharacterIndex(targetId) : null;
  const targetLabel = type === 'character' && characterIndex !== -1 ? `キャラクター #${characterIndex + 1}` : 'キャラクター';
  showToast(`${targetLabel}画像を削除しました`);
}

function updateCharacterImage(characterId, base64Data) {
  const target = characterImages.find(c => c.id === characterId);
  if (target) {
    target.base64 = base64Data;
    saveCharacterSheet();
  }
}

function getCharacterIndex(characterId) {
  return characterImages.findIndex(c => c.id === characterId);
}

function updateCharacterName(characterId, name) {
  const target = characterImages.find(c => c.id === characterId);
  if (target) {
    target.name = name;
    saveCharacterSheet();
  }
}

// 画像をリサイズしてBase64に変換
async function resizeImageToBase64(file, maxWidth = 800, maxHeight = 800, quality = 0.85) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      const img = new Image();

      img.onload = () => {
        // 元の画像サイズ
        let width = img.width;
        let height = img.height;

        // アスペクト比を保ったままリサイズ
        if (width > maxWidth || height > maxHeight) {
          const ratio = Math.min(maxWidth / width, maxHeight / height);
          width = Math.floor(width * ratio);
          height = Math.floor(height * ratio);
        }

        // Canvasで描画
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);

        // Base64に変換
        const resizedBase64 = canvas.toDataURL('image/jpeg', quality);
        resolve(resizedBase64);
      };

      img.onerror = () => reject(new Error('画像の読み込みに失敗しました'));
      img.src = e.target.result;
    };

    reader.onerror = () => reject(new Error('ファイルの読み込みに失敗しました'));
    reader.readAsDataURL(file);
  });
}

// Base64データURIをBlobに変換
function base64ToBlob(base64Data) {
  const parts = base64Data.split(';base64,');
  const contentType = parts[0].split(':')[1];
  const raw = window.atob(parts[1]);
  const rawLength = raw.length;
  const uInt8Array = new Uint8Array(rawLength);

  for (let i = 0; i < rawLength; ++i) {
    uInt8Array[i] = raw.charCodeAt(i);
  }

  return new Blob([uInt8Array], { type: contentType });
}

// 画像URLをBase64 data URIに変換
async function convertImageToBase64(imagePath) {
  try {
    console.log('画像を読み込み中:', imagePath);
    const response = await fetch(imagePath);
    if (!response.ok) {
      throw new Error(`Failed to fetch image: ${response.status}`);
    }
    const blob = await response.blob();
    console.log(`画像読み込み完了 (size: ${blob.size} bytes, type: ${blob.type})`);

    // BlobをBase64に変換
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        console.log('Base64変換完了');
        resolve(reader.result);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  } catch (error) {
    console.error('画像の変換に失敗しました:', error);
    throw error;
  }
}

// FAL CDNに画像をアップロード（Base64 data URIから）
async function uploadToFalCDN(base64DataUri, filename) {
  console.log(`FAL CDNへのアップロード開始: ${filename}`);

  try {
    // Base64 data URIからBlobに変換
    const blob = base64ToBlob(base64DataUri);
    const mimeType = blob.type;
    console.log(`Blob作成完了 (size: ${blob.size} bytes, type: ${mimeType})`);

    // Step 1: 2段階アップロード方式を試行
    const initiateEndpoints = [
      'https://rest.alpha.fal.ai/storage/upload/initiate?storage_type=fal-cdn-v3',
      'https://rest.alpha.fal.ai/storage/upload/initiate?storage_type=fal-cdn',
      'https://rest.alpha.fal.ai/storage/upload/initiate'
    ];

    for (const endpoint of initiateEndpoints) {
      try {
        console.log(`Initiate試行中: ${endpoint}`);

        // 2-1. Initiate request
        const initiateRes = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Authorization': `Key ${falApiKey}`,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify({
            content_type: mimeType,
            file_name: filename
          })
        });

        if (!initiateRes.ok) {
          console.warn(`Initiate失敗 (${initiateRes.status}): ${endpoint}`);
          continue;
        }

        const data = await initiateRes.json();
        const uploadUrl = data.upload_url || data.uploadUrl;
        const fileUrl = data.file_url || data.fileUrl || data.url;

        if (!uploadUrl || !fileUrl) {
          console.warn('Upload URLまたはFile URLが取得できませんでした');
          continue;
        }

        console.log(`Initiate成功! File URL: ${fileUrl}`);

        // 2-2. Upload (PUT request)
        console.log(`実際のアップロード中: ${uploadUrl}`);
        const uploadRes = await fetch(uploadUrl, {
          method: 'PUT',
          headers: { 'Content-Type': mimeType },
          body: blob
        });

        if (!uploadRes.ok) {
          console.warn(`Upload失敗 (${uploadRes.status})`);
          continue;
        }

        // 成功！
        console.log(`✓ FAL CDNアップロード成功: ${fileUrl}`);
        return { url: fileUrl, error: null };

      } catch (err) {
        console.warn(`Initiate/Upload失敗: ${endpoint} (フォールバックに進みます)`);
        continue;
      }
    }

    // Step 2: フォールバック - FormData方式
    console.log('2段階アップロード失敗、FormData方式を試行');
    const legacyEndpoints = [
      'https://api.fal.ai/v1/storage/upload',
      'https://api.fal.run/v1/storage/upload',
      'https://fal.run/api/v1/storage/upload',
      'https://fal.ai/api/v1/storage/upload'
    ];

    for (const endpoint of legacyEndpoints) {
      try {
        console.log(`FormDataアップロード試行中: ${endpoint}`);

        const formData = new FormData();
        formData.append('file', blob, filename);
        formData.append('content_type', mimeType);
        formData.append('filename', filename);

        const response = await fetch(endpoint, {
          method: 'POST',
          headers: { 'Authorization': `Key ${falApiKey}` },
          body: formData
        });

        if (!response.ok) {
          console.warn(`FormDataアップロード失敗 (${response.status}): ${endpoint} (フォールバックに進みます)`);
          continue;
        }

        const data = await response.json();
        const url = data.url || data.file_url || data.fileUrl;

        if (url) {
          console.log(`✓ FormDataアップロード成功: ${url}`);
          return { url, error: null };
        }

      } catch (err) {
        console.warn(`FormDataアップロード失敗: ${endpoint} (フォールバックに進みます)`);
        continue;
      }
    }

    // 全て失敗した場合は静かにBase64フォールバック
    console.warn('⚠ FAL CDNアップロード全試行失敗。Base64にフォールバックします。');
    return { url: '', error: null };

  } catch (error) {
    console.warn('⚠ アップロード処理で例外発生。Base64にフォールバックします。');
    return { url: '', error: null };
  }
}

// Base64画像をFAL AIにアップロード
async function uploadBase64ToFal(base64Data, imageType) {
  try {
    console.log(`${imageType}画像のアップロード開始`);
    // Base64をBlobに変換
    const blob = base64ToBlob(base64Data);
    console.log(`Blob作成完了 (size: ${blob.size} bytes, type: ${blob.type})`);

    // FormDataを作成
    const formData = new FormData();
    formData.append('file', blob, `${imageType}.jpg`);

    console.log('FAL AIストレージAPIにアップロード中...');
    // FAL AIのストレージAPIにアップロード
    const response = await fetch('https://fal.run/storage/upload', {
      method: 'POST',
      headers: {
        'Authorization': `Key ${falApiKey}`
      },
      body: formData
    });

    console.log(`アップロードレスポンス status: ${response.status}`);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('アップロードエラー:', errorText);
      throw new Error(`Upload failed: ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    console.log(`${imageType} image uploaded successfully:`, data);

    // FAL AIのレスポンス形式に応じてURLを取得
    return data.url || data.file_url || data.access_url;
  } catch (error) {
    console.error(`Failed to upload ${imageType} image:`, error);
    throw error;
  }
}

// ローカル画像パスからBlobを取得してFAL AIにアップロード
async function uploadImageToFal(imagePath, imageType) {
  try {
    console.log(`${imageType}画像をローカルから読み込み中: ${imagePath}`);
    // 画像をfetchで取得
    const response = await fetch(imagePath);
    if (!response.ok) {
      throw new Error(`Failed to fetch image: ${response.status}`);
    }
    const blob = await response.blob();
    console.log(`Blob作成完了 (size: ${blob.size} bytes, type: ${blob.type})`);

    // FormDataを作成
    const formData = new FormData();
    formData.append('file', blob, `${imageType}.jpg`);

    console.log('FAL AIストレージAPIにアップロード中...');
    // FAL AIのストレージAPIにアップロード
    const uploadResponse = await fetch('https://fal.run/api/upload', {
      method: 'POST',
      headers: {
        'Authorization': `Key ${falApiKey}`
      },
      body: formData
    });

    console.log(`アップロードレスポンス status: ${uploadResponse.status}`);

    if (!uploadResponse.ok) {
      const errorText = await uploadResponse.text();
      console.error('アップロードエラー:', errorText);
      throw new Error(`Upload failed: ${uploadResponse.status} - ${errorText}`);
    }

    const data = await uploadResponse.json();
    console.log(`${imageType} image uploaded successfully:`, data);

    // FAL AIのレスポンス形式に応じてURLを取得
    return data.url || data.file_url || data.access_url;
  } catch (error) {
    console.error(`Failed to upload ${imageType} image:`, error);
    throw error;
  }
}


// ===========================
// 画像ライブラリ管理
// ===========================

// 画像ライブラリをロード
async function loadImageLibrary() {
  try {
    const data = await chrome.storage.local.get('imageLibrary');
    imageLibrary = data.imageLibrary || [];
    console.log('Image library loaded:', imageLibrary.length, 'images');
  } catch (error) {
    console.error('Failed to load image library:', error);
    imageLibrary = [];
  }
}

// 画像ライブラリを保存
async function saveImageLibrary() {
  try {
    await chrome.storage.local.set({ imageLibrary });
    console.log('Image library saved:', imageLibrary.length, 'images');
  } catch (error) {
    console.error('Failed to save image library:', error);
    showToast('画像の保存に失敗しました');
  }
}

// 画像をライブラリに追加
async function addImageToLibrary(file) {
  try {
    const base64Data = await resizeImageToBase64(file, 800, 800, 0.85);
    const thumbnail = await resizeImageToBase64(file, 200, 200, 0.8);

    const imageData = {
      id: 'img_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
      name: file.name,
      base64Data: base64Data,
      thumbnail: thumbnail,
      uploadDate: new Date().toISOString()
    };

    imageLibrary.push(imageData);
    await saveImageLibrary();

    showToast('画像「' + file.name + '」を追加しました');
    renderLibraryGrid();
  } catch (error) {
    console.error('Failed to add image to library:', error);
    showToast('画像の追加に失敗しました');
  }
}

// ライブラリから画像を削除
async function removeImageFromLibrary(imageId) {
  const index = imageLibrary.findIndex(img => img.id === imageId);
  if (index !== -1) {
    const imageName = imageLibrary[index].name;
    imageLibrary.splice(index, 1);
    await saveImageLibrary();
    showToast('画像「' + imageName + '」を削除しました');
    renderLibraryGrid();
  }
}

// 画像ライブラリグリッドを描画
function renderLibraryGrid() {
  const libraryGrid = document.getElementById('libraryGrid');
  const libraryEmpty = document.getElementById('libraryEmpty');

  if (imageLibrary.length === 0) {
    libraryGrid.style.display = 'none';
    libraryEmpty.style.display = 'block';
    return;
  }

  libraryGrid.style.display = 'grid';
  libraryEmpty.style.display = 'none';
  libraryGrid.innerHTML = '';

  imageLibrary.forEach(image => {
    const item = document.createElement('div');
    item.className = 'library-image-item';
    item.innerHTML = '<img src="' + image.thumbnail + '" alt="' + image.name + '"><button class="library-image-delete" data-id="' + image.id + '">×</button>';

    item.addEventListener('click', (e) => {
      if (!e.target.classList.contains('library-image-delete')) {
        selectImageFromLibrary(image);
      }
    });

    const deleteBtn = item.querySelector('.library-image-delete');
    deleteBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (confirm('画像「' + image.name + '」を削除しますか？')) {
        removeImageFromLibrary(image.id);
      }
    });

    libraryGrid.appendChild(item);
  });
}

// ライブラリから画像を選択
function selectImageFromLibrary(image) {
  if (currentLibraryTarget && currentLibraryTarget.type === 'character') {
    const characterId = currentLibraryTarget.id;
    updateCharacterImage(characterId, image.base64Data);
    renderCharacterList();
    saveCharacterSheet();

    const characterIndex = getCharacterIndex(characterId);
    const label = characterIndex !== -1 ? `キャラクター #${characterIndex + 1}` : 'キャラクター';
    showToast(`${label}に「${image.name}」を設定しました`);
  }

  closeImageLibraryModal();
}

// 画像ライブラリモーダルを開く
function openImageLibraryModal(target) {
  currentLibraryTarget = typeof target === 'string' ? { type: target } : target;
  const modal = document.getElementById('imageLibraryModal');
  modal.style.display = 'flex';
  renderLibraryGrid();
}

// 画像ライブラリモーダルを閉じる
function closeImageLibraryModal() {
  const modal = document.getElementById('imageLibraryModal');
  modal.style.display = 'none';
  currentLibraryTarget = null;
}

// ファイル選択からアップロード
async function handleLibraryFileSelect(e) {
  const files = Array.from(e.target.files);
  for (const file of files) {
    await addImageToLibrary(file);
  }
  e.target.value = '';
}

// ドラッグ&ドロップでアップロード
function handleLibraryDrop(e) {
  e.preventDefault();
  const uploadArea = document.getElementById('libraryUploadArea');
  uploadArea.classList.remove('dragover');

  const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
  files.forEach(file => addImageToLibrary(file));
}

function handleLibraryDragOver(e) {
  e.preventDefault();
  const uploadArea = document.getElementById('libraryUploadArea');
  uploadArea.classList.add('dragover');
}

function handleLibraryDragLeave(e) {
  const uploadArea = document.getElementById('libraryUploadArea');
  uploadArea.classList.remove('dragover');
}

// ===========================
// 画像ライブラリイベントリスナー初期化
// ===========================

async function initImageLibrary() {
  await loadImageLibrary();

  const closeLibraryBtn = document.querySelector('.close-library');
  const selectFileBtn = document.getElementById('librarySelectFileBtn');
  const fileInput = document.getElementById('libraryFileInput');
  const uploadArea = document.getElementById('libraryUploadArea');
  const modal = document.getElementById('imageLibraryModal');

  if (closeLibraryBtn) {
    closeLibraryBtn.addEventListener('click', closeImageLibraryModal);
  }

  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target.id === 'imageLibraryModal') {
        closeImageLibraryModal();
      }
    });
  }

  if (selectFileBtn && fileInput) {
    selectFileBtn.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', handleLibraryFileSelect);
  }

  if (uploadArea) {
    uploadArea.addEventListener('drop', handleLibraryDrop);
    uploadArea.addEventListener('dragover', handleLibraryDragOver);
    uploadArea.addEventListener('dragleave', handleLibraryDragLeave);
  }
}
